import Aerodynamics
import Economics


from Economics import crew_salary
from Performance.Mission import mission


print(Aerodynamics)
print(Economics)
print(crew_salary)
print(mission)
