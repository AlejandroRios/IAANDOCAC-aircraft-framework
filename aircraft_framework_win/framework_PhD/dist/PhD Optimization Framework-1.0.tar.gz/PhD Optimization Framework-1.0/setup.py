from setuptools import setup, find_packages

setup(
    name         = 'PhD Optimization Framework',
    version      = '1.0',
    author       = 'Alejandro Rios',
    packages     = find_packages(),
)
